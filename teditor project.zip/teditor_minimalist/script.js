function formatText(command) {
  document.execCommand(command, false, null);
}